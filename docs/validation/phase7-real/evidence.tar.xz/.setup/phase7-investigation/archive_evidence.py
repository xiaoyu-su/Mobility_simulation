"""Publish byte-verified records only after every experiment has terminated."""
from pathlib import Path
import hashlib,json,shutil,sys,tarfile
from tools.paired_eval.__main__ import source_record

W=Path('/workspace');ROOT=W/'Mobility_simulation';I=W/'market_inputs';R=W/'market_results'
DEST=ROOT/'docs/validation/phase7-real';DEST.mkdir(parents=True,exist_ok=True)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):h.update(block)
    return h.hexdigest()
def save(path,data):path.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
source=source_record();assert source['code_digest']=='d0dd474cef8aae0ccbd1f5c94008788b02648efb523a167c3bbe11c1722f84da'
save(R/'investigation/frozen_source.json',source)
folders=[R/'manhattan_10pct_seed0']+[p for p in sorted((R/'ablations').iterdir()) if p.is_dir()]
inventory=[]
for p in folders:
    m=json.loads((p/'manifest.json').read_text())
    assert m['status'] in ['complete','failed'],p
    assert m['source']['code_digest']==source['code_digest']
    inventory.append(dict(case=p.name,status=m['status'],error=m.get('error'),
        validated_pairs=len(m['validated_pairs']),
        runs=[dict(arm=r['arm'],status=r['status'],returncode=r.get('returncode'),output=r['output']) for r in m['runs']],
        unrun_arms=sorted(set(['no_repo','repo'])-{r['arm'] for r in m['runs']})))
inventory_record=dict(cases=inventory,canonical_attempted_runs=sum(len(x['runs']) for x in inventory),
    canonical_successful_runs=sum(r['status']=='complete' for x in inventory for r in x['runs']),
    canonical_failed_runs=sum(r['status']=='failed' for x in inventory for r in x['runs']),
    complete_validated_pairs=sum(x['validated_pairs'] for x in inventory),
    observer_replays=1,observer_replay_status='same booked-completion failure, five key files byte-identical')
save(R/'investigation/run_inventory.json',inventory_record)
checks=json.loads((R/'investigation/integrity.json').read_text())
assert not checks['pending_cases']
assert checks['completed_runs']==inventory_record['canonical_successful_runs']
files={};omitted=[]
def collect(path):
    if path.is_file():
        assert not path.is_symlink()
        arc=str(path.relative_to(W))
        if path.suffix=='.npy':omitted.append(dict(path=arc,size_bytes=path.stat().st_size,sha256=sha(path)));return
        if 'matplotlib' in path.parts or '__pycache__' in path.parts:return
        files[arc]=path
    else:
        for p in sorted(path.rglob('*')):
            if p.is_file():collect(p)
for path in [I/'manhattan_10pct_seed0',I/'ablation_bundles',I/'investigation_cache',
    I/'download_manifest.json',I/'extraction_manifest.json',I/'manhattan_tlc_node_zone_info.csv',I/'zone_mapping_manifest.json',
    I/'taxi_zone_lookup.csv',I/'zenodo_record.json',R/'manhattan_10pct_seed0',R/'ablations',R/'investigation']:
    collect(path)
for path in (W/'.setup/phase7-investigation').iterdir():
    if path.is_file():collect(path)
for path in (W/'.setup/phase7-real').iterdir():
    if path.is_file() and path.suffix in ['.txt','.json']:collect(path)
for rel,digest in source['code_files_sha256'].items():
    path=ROOT/rel;assert sha(path)==digest
    files['frozen_source/'+rel]=path
files['frozen_source/LICENSE']=ROOT/'LICENSE'
files['frozen_source/AGENTS.md']=ROOT/'AGENTS.md'
archive=DEST/'evidence.tar.xz'
entries=[]
with tarfile.open(archive,'w:xz',preset=9) as tar:
    for arc,path in sorted(files.items()):
        entries.append(dict(path=arc,size_bytes=path.stat().st_size,sha256=sha(path)))
        tar.add(path,arcname=arc,recursive=False)
with tarfile.open(archive,'r:xz') as tar:
    for entry in entries:
        f=tar.extractfile(entry['path']);h=hashlib.sha256()
        for block in iter(lambda:f.read(2**20),b''):h.update(block)
        assert h.hexdigest()==entry['sha256'],entry['path']
save(DEST/'archive_index.json',dict(archive=archive.name,sha256=sha(archive),size_bytes=archive.stat().st_size,
    archived_file_count=len(entries),all_archived_bytes_verified=True,files=entries,
    omitted_network_matrices=omitted,omission_reason='Unchanged public TUM binary matrices; restore exact bytes from verified Zenodo archive.'))
for p in (R/'investigation').iterdir():
    if p.is_file() and p.suffix in ['.json','.csv','.svg','.png','.md']:shutil.copyfile(p,DEST/p.name)
save(DEST/'validation.json',dict(**{k:v for k,v in inventory_record.items() if k!='cases'},
    source_digest=source['code_digest'],simulation_git_head=source['git_head'],production_source_changed=False,
    full_suite='Not rerun for data/documentation-only investigation; previous 310-test gate uses identical source digest, see ../phase7/',
    all_successful_runs_independently_checked=True,canonical_failures_preserved=True,
    completed_runs_with_early_pickups=sum(not x['source_reference_no_early_pickups'] for x in checks['checks']),
    complete_simulation_does_not_mean_valid_clock_or_calibration=True,
    code_default_early_admission_unfixed=True,calibration_complete=False,
    artifact_archive_sha256=sha(archive),archived_file_count=len(entries),all_archived_bytes_verified=True,
    final_source_unchanged=source_record()['code_digest']==source['code_digest']))
print(json.dumps(dict(**{k:v for k,v in inventory_record.items() if k!='cases'},archive_bytes=archive.stat().st_size,archived_files=len(entries)),indent=2))
