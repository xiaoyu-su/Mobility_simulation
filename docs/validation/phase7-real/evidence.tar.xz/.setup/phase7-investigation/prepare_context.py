from pathlib import Path
import json,shutil
import numpy as np,pandas as pd
from ablation_lib import prepare,choose,eligible,digest,BASE,OUT

prepare('uniform_clock_1s',clock=True,spatial=True,initial=True)
records=pd.read_parquet('/workspace/market_inputs/investigation_cache/all_day_records.parquet')
original=json.loads((BASE/'manifest.json').read_text())
train=records[records.service_date.isin(original['training_dates'])].copy()
target=records[records.service_date.eq(original['target_date'])].copy()
observed=pd.read_csv(OUT/'uniform_clock_1s/observed_cohort.csv')
mapping=pd.read_csv(BASE/'zones/network/node_zone_info.csv')
centroids=mapping[mapping.is_centroid.eq(1)].set_index('zone_id').node_index.to_dict()
tt=np.load(BASE/'network/ff/tables/nn_fastest_tt.npy',mmap_mode='r')
train['base_route_s']=[tt[centroids[int(a)],centroids[int(b)]] for a,b in zip(train.PULocationID,train.DOLocationID)]
train['log_ratio']=np.log((train.dropoff_s-train.pickup_s)/train.base_route_s)
train['bin']=(train.pickup_s//900*900).astype(int)

def context(name,start,dynamic=False):
    dest=OUT/name
    if dest.exists():raise ValueError('Existing context variant '+name)
    shutil.copytree(OUT/'uniform_clock_1s',dest)
    meta=json.loads((dest/'manifest.json').read_text());params=json.loads((dest/'parameters.json').read_text())
    warm=target[target.request_s.ge(start)&target.request_s.lt(25200)].copy().sort_values(['request_s','trip_id'])
    warm['request_id']=np.arange(len(observed),len(observed)+len(warm))
    warm['start']=[choose(i,'origin',z) for i,z in zip(warm.trip_id,warm.PULocationID)]
    warm['end']=[choose(i,'destination',z) for i,z in zip(warm.trip_id,warm.DOLocationID)]
    measured=observed.copy();measured['is_evaluation_request']=True;warm['is_evaluation_request']=False
    combined=pd.concat([warm,measured],ignore_index=True).sort_values(['request_s','trip_id'])
    combined.to_csv(dest/'observed_cohort.csv',index=False)
    demand=combined[['request_id','start','end']].copy();demand['rq_time']=np.floor(combined.request_s).astype(int)
    demand['latest_start_time']=combined.request_s+np.ceil(combined.observed_wait_s)+300
    demand.to_csv(dest/'demand/requests.csv',index=False)
    train.to_csv(dest/'training_cohort.csv',index=False)
    from tools.synthetic_market.build import historical_profiles
    fc,supply=historical_profiles(train,3,sorted(eligible),start,36900,900,.58)
    fc.to_csv(dest/'forecasts/900/historical.csv',index=False)
    supply=supply[supply.time.lt(36000)].copy();supply['share_active_fleet_size']=np.minimum(supply.modeled_active_vehicles/775,1)
    supply.to_csv(dest/'supply_profile.csv',index=False)
    supply[['time','share_active_fleet_size']].to_csv(dest/'fleetctrl/elastic_fleet_size/active.csv',index=False)
    initial=train.loc[train.request_s.ge(start)&train.request_s.lt(start+900),'PULocationID'].value_counts()
    if initial.empty:raise ValueError('No historical initial distribution')
    rows=[]
    for zone,count in initial.items():
        pool=eligible[int(zone)];rows.extend(dict(node_index=n,probability=count/initial.sum()/len(pool)) for n in pool)
    pd.DataFrame(rows).to_csv(dest/'fleetctrl/initial_vehicle_distribution/market_network/initial.csv',index=False)
    factors=pd.read_csv(BASE/'network/calibrated_factors.csv')
    warm_factors=[]
    warm_logs=train.loc[train.pickup_s.ge(start)&train.pickup_s.lt(25200),'log_ratio']
    for t in range(start,25200,900):
        values=train.loc[train.bin.eq(t),'log_ratio']
        if len(values)<3:values=warm_logs
        warm_factors.append(dict(simulation_time=t,travel_time_factor=float(np.exp(values.mean()+params['network_tt_noise_sigma']**2/2))))
    pd.concat([pd.DataFrame(warm_factors),factors]).to_csv(dest/'network/calibrated_factors.csv',index=False)
    params['start_time']=start
    if dynamic:params.update(op_dyn_fs_method='TimeBasedFS',op_act_fs_file='active.csv',infra_structure_name='market_infra',op_depot_file='depots.csv')
    (dest/'parameters.json').write_text(json.dumps(params,indent=2)+'\n')
    meta.update(target_count=len(combined),training_count=len(train))
    meta['derivation']=dict(parent_manifest_sha256=digest(OUT/'uniform_clock_1s/manifest.json'),script_sha256=digest(__file__),
        changes=['historical full-day carry-in for supply/arrival forecasts',f'warm-up from {start} with measured request cohort 25200..36000',
                 'fixed 775 total fleet; measured-window travel factors/noise unchanged',f'dynamic profile enabled: {dynamic}'],
        evaluation_start=25200,evaluation_end=36000,evaluation_request_count=len(observed),warmup_request_count=len(warm),
        evaluation_request_ids_preserved=True)
    meta['output_sha256']={str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file() and p.name!='manifest.json'}
    (dest/'manifest.json').write_text(json.dumps(meta,indent=2,allow_nan=False)+'\n')
    print(name,'warmup',len(warm),'evaluated',len(observed),'first active',supply.modeled_active_vehicles.iloc[0],flush=True)
context('uniform_clock_warmup_1h',21600)
context('uniform_clock_warmup_2h',18000)
context('uniform_clock_warmup_2h_dynamic',18000,True)
