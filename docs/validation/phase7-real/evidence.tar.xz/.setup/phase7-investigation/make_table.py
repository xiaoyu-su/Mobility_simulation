from pathlib import Path
import pandas as pd
p=Path('/workspace/market_results/investigation');x=pd.read_csv(p/'cohort_diagnostics.csv')
cols=['case','arm','completed','raw_wait_negative_count','raw_wait_median_s','arrival_median_abs_error_s','boarding_departure_wait_median_s','pickup_total_median_abs_error_s','post_boarding_ride_median_s','model_pooled_share_served']
lines=['# Full fixed-cohort results','',
    'All rows use the same 3,150 source trip IDs. Successful individual arms of failed pairs remain in the CSV with pair_status=failed and are not valid paired policy evidence. Arrival error compares served IDs with valid source on-scene records; departure error compares the served source pickup cohort. Early source-clock service invalidates floor-based benchmarks. Values below are rounded; the CSV retains full precision.',
    '', '| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']
for r in x[cols].itertuples(index=False,name=None):
    lines.append('| '+' | '.join(f'{v:.2f}' if isinstance(v,float) else str(v) for v in r)+' |')
(p/'results_table.md').write_text('\n'.join(lines)+'\n')
