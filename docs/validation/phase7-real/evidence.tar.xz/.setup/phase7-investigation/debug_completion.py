"""Read-only observer for the failed exact-clock run; no model behavior changes."""
from pathlib import Path
import json,runpy,sys
from src.simulation.Vehicles import SimulationVehicle
from src.FleetSimulationBase import FleetSimulationBase

OUT=Path('/workspace/market_results/investigation/clock_debug_trace.jsonl')
def emit(data):
    with OUT.open('a') as f:f.write(json.dumps(data,default=str)+'\n')
original_move=SimulationVehicle._move
def move(self,t,remaining,update_start):
    if self.vid==356 and (t>=34078 and (int(t)%900==0 or 40370<=t<=40380)):
        emit(dict(event='movement_before',time=t,remaining=remaining,position=self.pos,
            route=self.cl_remaining_route,multiplier=self.cl_tt_multiplier,status=str(self.status),
            tasks=[str(x) for x in self.assigned_route],passengers=[p.get_rid() for p in self.pax]))
    result=original_move(self,t,remaining,update_start)
    if self.vid==356 and 40370<=t<=40380:
        emit(dict(event='movement_after',time=t,result=result,position=self.pos,route=self.cl_remaining_route))
    return result
SimulationVehicle._move=move
original_drain=FleetSimulationBase.record_remaining_assignments
def drain(self):
    original_drain(self)
    for v in self.sim_vehicles.values():
        if v.pax:emit(dict(event='unfinished_after_drain',vehicle=v.vid,position=v.pos,route=v.cl_remaining_route,
            remaining=v.cl_remaining_time,status=str(v.status),tasks=[str(x) for x in v.assigned_route],passengers=[p.get_rid() for p in v.pax]))
FleetSimulationBase.record_remaining_assignments=drain
sys.argv=['worker','--bundle','/workspace/market_inputs/ablation_bundles/clock_1s','--output',
    '/workspace/market_results/investigation/clock_debug_run','--seed','0','--policy','repo']
runpy.run_module('tools.synthetic_market.worker',run_name='__main__')
