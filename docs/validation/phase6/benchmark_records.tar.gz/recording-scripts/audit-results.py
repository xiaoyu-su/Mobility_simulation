"""Retain independent final-source output checks without changing tested source."""
from collections import Counter
from datetime import datetime,timezone
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd

ROOT=Path('/workspace/Mobility_simulation');sys.path.insert(0,str(ROOT))
from tools.paired_eval.__main__ import source_record
from tools.paired_eval.metrics import per_driver_metrics
from src.misc.seeding import file_digest,canonical_digest

BASE=Path('/workspace/.setup/phase6');SUITE=BASE/'final-suite';BENCH=BASE/'final-benchmarks'
DEST=ROOT/'docs/validation/phase6';DEST.mkdir(parents=True,exist_ok=True)
source=json.loads((SUITE/'source.json').read_text())
assert source==source_record(),'Source or HEAD changed during final validation'
prior=json.loads((ROOT/'docs/validation/phase5c/source.json').read_text())
assert all(source['code_files_sha256'][k]==v for k,v in prior['code_files_sha256'].items())
reference=json.loads((ROOT/'tests/regression/baselines/manifest.json').read_text())
assert all(file_digest(ROOT/k)==v for k,v in reference['input_sha256'].items())
suite=ET.parse(SUITE/'junit.xml').getroot().find('testsuite')
assert int(suite.attrib['failures'])==int(suite.attrib['errors'])==int(suite.attrib['skipped'])==0
counts=Counter(t.attrib['classname'] for t in suite.findall('testcase'))
def hashes(folder):
    return {str(p.relative_to(folder)):file_digest(p) for p in sorted(folder.rglob('*')) if p.is_file()}

full=[];historical=[]
for location in [SUITE/'simulation-runs',BENCH]:
    for final in sorted(location.rglob('final_state.csv')):
        folder=final.parent
        if not (folder/'standard_eval.csv').exists():continue
        users=pd.read_csv(folder/'1_user-stats.csv')
        assert len(users)==100 and users.request_id.is_unique,folder
        assert users.pickup_time.notna().equals(users.dropoff_time.notna()),folder
        independent=(folder/'random_streams.json').exists()
        if independent:
            audit=json.loads((folder/'random_streams.json').read_text())
            assert sum(x['count'] for x in audit['demand'].values())==100
        drivers=per_driver_metrics(folder)
        assert drivers.completed_trips.sum()==users.dropoff_time.notna().sum()
        decisions=folder/'driver_acceptance_op_0.csv'
        if decisions.exists():
            rows=pd.read_csv(decisions);served=set(users.loc[users.dropoff_time.notna(),'request_id'])
            assert set(rows.loc[rows.accepted,'request_id']).issubset(served),folder
            assert set(rows.loc[rows.terminal_decline,'request_id']).isdisjoint(served),folder
        full.append(dict(directory=str(folder.relative_to(BASE)),requests=len(users),completed=int(users.dropoff_time.notna().sum()),
                         independent_input_audit=independent,completed_accepted_bookings=True,driver_accounting_valid=True,output_sha256=hashes(folder)))
        if folder.is_relative_to(SUITE/'simulation-runs'):
            old=Path('/workspace/.setup/phase5c/final-suite/simulation-runs')/folder.relative_to(SUITE/'simulation-runs')
            if (old/'final_state.csv').exists():
                tables=[]
                for name in ['1_user-stats.csv','standard_eval.csv','2-0_op-stats.csv','final_state.csv',
                    'driver_acceptance_op_0.csv','driver_choice_op_0.csv','future_value_op_0.csv',
                    'ranked_insertion_op_0.csv','forbid_rematch_op_0.csv']:
                    assert (old/name).exists()==(folder/name).exists(),(folder,name)
                    if (old/name).exists():
                        pd.testing.assert_frame_equal(pd.read_csv(old/name),pd.read_csv(folder/name),check_exact=True)
                        tables.append(name)
                historical.append(dict(directory=str(folder.relative_to(SUITE/'simulation-runs')),exact_tables=tables))

windows=[];experiments=[]
for location in [SUITE/'simulation-runs',BENCH]:
    for manifest_path in sorted(location.rglob('manifest.json')):
        manifest=json.loads(manifest_path.read_text())
        if 'windows' not in manifest:continue
        folder=manifest_path.parent
        assert manifest['status']=='complete' and manifest['source']==source,folder
        assert len(manifest['validated_pairs'])==len(manifest['seeds'])*len(manifest['windows'])
        assert manifest['maximum_active_workers']==manifest['workers']
        for run in manifest['runs']:
            assert run['status']=='complete' and run['returncode']==0
            output=Path(run['output']);state=json.loads((output/'window_state.json').read_text())
            assert state['source']==source
            cohort=pd.read_csv(output/'cohort_observations.csv',dtype={'request_id':str})
            assert len(cohort)==state['cohort_count'] and cohort.request_id.is_unique
            assert canonical_digest(cohort.request_id.tolist())==state['cohort_request_ids_sha256']
            assert cohort.rq_time.ge(state['start']).all() and cohort.rq_time.lt(state['end']).all()
            assert cohort.dropoff_time.dropna().lt(state['horizon']).all()
            assert cohort.pickup_time.dropna().lt(state['horizon']).all()
            counts_status=cohort.status.value_counts().to_dict()
            assert sum(counts_status.values())==len(cohort)
            credit=pd.read_csv(output/'cohort_drivers.csv')
            assert credit.completed_cohort_trips.sum()==cohort.status.eq('completed').sum()
            assert credit.completed_cohort_gross_fare_cent.sum()==cohort.fare.sum()
            activity=output/'2-0_op-stats.csv'
            if activity.exists():
                legs=pd.read_csv(activity)
                assert not legs.duplicated().any()
                for _,group in legs.groupby('vehicle_id'):
                    group=group.sort_values(['start_time','end_time'])
                    assert (group.end_time>=group.start_time).all()
                    assert np.all(group.start_time.to_numpy()[1:]>=group.end_time.to_numpy()[:-1]-1e-6)
            request_state=pd.read_csv(output/'request_state.csv')
            decisions=output/'driver_acceptance_op_0.csv'
            if decisions.exists():
                d=pd.read_csv(decisions)
                served=set(request_state.loc[request_state.pickup_time.notna(),'request_id'])
                assert set(d.loc[d.terminal_decline,'request_id']).isdisjoint(served)
            windows.append(dict(directory=str(output.relative_to(BASE)),cohort_count=len(cohort),statuses=counts_status,
                snapshot_sha256=state['snapshot_sha256'],active_policy=state['active_policy'],
                source_digest=state['source']['code_digest'],output_sha256=hashes(output)))
        experiments.append(dict(directory=str(folder.relative_to(BASE)),seeds=manifest['seeds'],
            workers=manifest['workers'],baseline_runs=len(manifest['baselines']),window_runs=len(manifest['runs']),
            validated_pairs=len(manifest['validated_pairs']),baseline_wall_seconds=manifest['baseline_wall_seconds'],
            task_wall_seconds=manifest['task_wall_seconds'],wall_seconds=manifest['wall_seconds']))

benchmarks=[]
for name in ['ranked','rematch','menus']:
    a=BENCH/f'{name}-workers-1';b=BENCH/f'{name}-workers-2'
    for report in ['seed_window_summary.csv','paired_window_comparison.csv']:
        pd.testing.assert_frame_equal(pd.read_csv(a/report),pd.read_csv(b/report),check_exact=True)
    for seed in [0,1,2]:
        for index in [0,1,2]:
            for arm in ['baseline','candidate']:
                for table in ['cohort_observations.csv','cohort_drivers.csv','window_final_state.csv','2-0_op-stats.csv']:
                    suffix=Path('tasks')/f'seed_{seed}'/f'window_{index}'/arm/'run'/table
                    pd.testing.assert_frame_equal(pd.read_csv(a/suffix),pd.read_csv(b/suffix),check_exact=True)
    ma=json.loads((a/'manifest.json').read_text());mb=json.loads((b/'manifest.json').read_text())
    for p in ['seed_window_summary.csv','paired_window_comparison.csv']:
        shutil.copy2(b/p,DEST/f'{name}-{p}')
    comparison=pd.read_csv(b/'paired_window_comparison.csv')
    selected=comparison[comparison.metric.isin(['completed_requests','observed_wait_mean_s','censored_requests'])]
    benchmarks.append(dict(name=name,serial_task_seconds=ma['task_wall_seconds'],parallel_task_seconds=mb['task_wall_seconds'],
        task_speed_ratio=ma['task_wall_seconds']/mb['task_wall_seconds'],
        serial_total_seconds=ma['wall_seconds'],parallel_total_seconds=mb['wall_seconds'],
        total_speed_ratio=ma['wall_seconds']/mb['wall_seconds'],reports_and_72_output_tables_exact=True,
        cohort_outcomes=selected[['window','metric','baseline_mean','candidate_mean','mean_difference','n_pairs']].to_dict('records')))

assert len(full)==182,(len(full),len(windows))
assert len(windows)==144,len(windows)
validation=dict(recorded_at_utc=datetime.now(timezone.utc).isoformat(),phase='6',branch='phase-6-windowed-evaluation',
    source_digest=source['code_digest'],tests=dict(passed=int(suite.attrib['tests']),failed=0,skipped=0,
        duration_seconds=float(suite.attrib['time']),case_counts=dict(counts)),
    suite_full_simulations=163,suite_restored_windows=32,additional_full_simulations=19,additional_restored_windows=112,
    measured_benchmark_full_simulations=18,measured_benchmark_restored_windows=108,
    basic_router_disabled_policy_full_simulations=1,basic_router_disabled_policy_restored_windows=4,
    total_full_simulations=len(full),total_restored_windows=len(windows),
    original_python_and_dependency_files_unchanged=len(prior['code_files_sha256']),original_input_hashes_unchanged=9,
    historical_full_runs_exact=len(historical),historical_output_tables_exact=sum(len(x['exact_tables']) for x in historical),
    full_baseline_accounting_and_accepted_completion_checked=True,window_censoring_explicit=True,
    benchmarks=benchmarks,experiments=experiments,
    timing_scope='One measured serial/parallel run per configuration on this environment while regression/compatibility work also ran; descriptive timings, not a guaranteed speedup.',
    inference_scope='Independent seeds within a window; candidate windows start baseline histories; no full-day candidate trajectory claim.')
for filename,data in [('validation.json',validation),('source.json',source),('run_checks.json',dict(full_simulations=full,restored_windows=windows)),
                     ('historical_compatibility.json',historical)]:
    (DEST/filename).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
for filename in ['pytest.txt','junit.xml']:
    shutil.copy2(SUITE/filename,DEST/filename)
for filename in ['checkpoint.txt','checkpoint-junit.xml','unit-checkpoint.txt','guard-checkpoint.txt','corrected-logging.txt',
                 'smoke-ranked.txt','smoke-rematch.txt','checkpoint-logging-benchmarks-console.txt']:
    shutil.copy2(BASE/filename,DEST/filename)
shutil.copy2(BASE/'router-compatibility.txt',DEST/'router-compatibility.txt')
shutil.copy2(BASE/'final-audit-selection-error.txt',DEST/'final-audit-selection-error.txt')
print(json.dumps({k:v for k,v in validation.items() if k not in ['benchmarks','experiments','tests']},indent=2))
for row in benchmarks:print(row['name'],row['task_speed_ratio'],row['total_speed_ratio'])
