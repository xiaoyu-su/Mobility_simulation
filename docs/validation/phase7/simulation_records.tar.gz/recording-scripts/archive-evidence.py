from pathlib import Path
import hashlib
import json
import tarfile

BASE=Path('/workspace/.setup/phase7');DEST=Path('/workspace/Mobility_simulation/docs/validation/phase7')
DEST.mkdir(parents=True,exist_ok=True)
groups={
 'simulation_records.tar.gz':[(BASE/'final-suite','suite'),(BASE/'final-cases','cases')],
 'checkpoint_records.tar.gz':[(BASE/name,'checkpoints/'+name) for name in
   ['checkpoint-tests','corrected-tests','second-corrected-tests','final-focused-tests',
    'checkpoint-interrupted-suite','checkpoint-shared-vehicle-cases']]
}
index={}
for name,roots in groups.items():
    archive=DEST/name;members={};originals={}
    with tarfile.open(archive,'w:gz') as tar:
        for folder,prefix in roots:
            for path in sorted(folder.rglob('*')):
                if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts:continue
                target=prefix+'/'+str(path.relative_to(folder))
                members[target]=hashlib.sha256(path.read_bytes()).hexdigest();originals[target]=path
                tar.add(path,arcname=target,recursive=False)
        if name=='simulation_records.tar.gz':
            for script in ['run-final-cases.py','audit-results.py','archive-evidence.py']:
                path=BASE/script;target='recording-scripts/'+script
                members[target]=hashlib.sha256(path.read_bytes()).hexdigest();originals[target]=path
                tar.add(path,arcname=target,recursive=False)
    checked=set()
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            assert member.isfile()
            digest=hashlib.sha256(tar.extractfile(member).read()).hexdigest()
            assert digest==members[member.name]==hashlib.sha256(originals[member.name].read_bytes()).hexdigest()
            checked.add(member.name)
    assert checked==set(members)
    index[name]=dict(size_bytes=archive.stat().st_size,regular_files=len(members),
        sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),file_sha256=members)
    print(name,len(members),archive.stat().st_size,flush=True)
(DEST/'archive_index.json').write_text(json.dumps(index,indent=2)+'\n')
validation=json.loads((DEST/'validation.json').read_text())
validation['archives']={name:{k:v for k,v in data.items() if k!='file_sha256'} for name,data in index.items()}
validation['artifact_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(DEST.iterdir())
                             if p.is_file() and p.name not in ['validation.json','README.md']}
(DEST/'validation.json').write_text(json.dumps(validation,indent=2,allow_nan=False)+'\n')
