import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/workspace/Mobility_simulation')
sys.path.insert(0,str(ROOT))
BASE=Path('/workspace/.setup/phase7/final-cases')
BASE.mkdir()
spec=importlib.util.spec_from_file_location('market_fixture',ROOT/'tests/integration/test_market_pipeline.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
cases=[('insertion','PoolingIRSOnly',True,'NetworkBasicWithStore',[]),
       ('immediate-future-proxy','PoolingIRSAssignmentBatchOptimization',False,'NetworkBasic',['--driver-model','classes','--future-value']),
       ('batch-classes','RidePoolingBatchAssignmentFleetcontrol',True,'NetworkTTMatrix',['--driver-model','classes']),
       ('dynamic-fleet','PoolingIRSOnly',True,'NetworkBasicWithStore',['--dynamic-fleet'])]
env=dict(os.environ,PYTHONHASHSEED='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg')
for name,controller,observed,router,features in cases:
    folder=BASE/name;folder.mkdir()
    trips,zones,network=module.fixture(folder/'source',observed,matrix=router=='NetworkTTMatrix')
    commands=[['build','--trips',str(trips),'--network',str(network),'--zone-map',str(zones),
               '--network-type',router,'--data-kind','fixture','--sample-fraction','1','--fleet-size','9',
               '--controller',controller,'--output',str(folder/'bundle'),*features,
               *(['--request-time-proxy-seconds','60'] if not observed else [])],
              ['run','--bundle',str(folder/'bundle'),'--seeds','0','1','2','--output',str(folder/'experiment')]]
    for index,args in enumerate(commands):
        command=[sys.executable,'-m','tools.synthetic_market',*args]
        (folder/f'command_{index}.json').write_text(json.dumps(dict(command=command,environment={k:env[k] for k in
             ['PYTHONHASHSEED','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','MPLBACKEND']}),indent=2)+'\n')
        print(name,args[0],flush=True)
        with (folder/f'{args[0]}.txt').open('w') as stream:
            result=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=1200)
        if result.returncode:raise RuntimeError(f'{name} failed: {folder}')
    print(name,'complete',flush=True)
