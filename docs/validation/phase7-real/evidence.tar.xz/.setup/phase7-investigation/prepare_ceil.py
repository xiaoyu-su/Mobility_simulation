"""Causal minute-grid sensitivity; keep all original measured trip identities."""
import json
import numpy as np,pandas as pd
from ablation_lib import prepare,digest,OUT
prepare('uniform_ceil_60s',spatial=True,initial=True)
dest=OUT/'uniform_ceil_60s'
observed=pd.read_csv(dest/'observed_cohort.csv');demand=pd.read_csv(dest/'demand/requests.csv')
demand['rq_time']=(np.ceil(observed.request_s/60)*60).astype(int)
demand['latest_start_time']=observed.request_s+np.ceil(observed.observed_wait_s)+300
demand.to_csv(dest/'demand/requests.csv',index=False)
params=json.loads((dest/'parameters.json').read_text());params['end_time']=36060
(dest/'parameters.json').write_text(json.dumps(params,indent=2)+'\n')
meta=json.loads((dest/'manifest.json').read_text())
meta['derivation']['changes'] += ['ceil admission to next minute, never admit early',
    'patience anchored to source request time',
    'extend simulation end by 60 seconds to admit every original 07:00–10:00 request; evaluation cohort unchanged']
meta['derivation']['script_sha256']=digest(__file__)
meta['output_sha256']={str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file() and p.name!='manifest.json'}
(dest/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
