"""Reproduce the two source-row keyed diagnostic caches from public data."""
from pathlib import Path
import hashlib,json
import numpy as np,pandas as pd,pyarrow.parquet as pq
from tools.synthetic_market.records import read_records

I=Path('/workspace/market_inputs');B=I/'manhattan_10pct_seed0';O=I/'investigation_cache'
O.mkdir(exist_ok=True)
if (O/'all_day_records.parquet').exists() or (O/'source_details.parquet').exists():
    raise ValueError('Use a new directory or preserve/remove existing caches explicitly before rebuilding')
meta=json.loads((B/'manifest.json').read_text())
mapping=pd.read_csv(B/'zones/network/node_zone_info.csv')
source=I/'fhvhv_tripdata_2019-11.parquet'
records,counts,inputs=read_records([source],[meta['target_date'],*meta['training_dates']],set(mapping.zone_id),0,.1)
records.to_parquet(O/'all_day_records.parquet',index=False)
identities={int(r.trip_id.split(':')[1]):r.trip_id for r in records.itertuples()}
selected=np.array(sorted(identities),dtype=np.int64)
columns=['hvfhs_license_num','request_datetime','on_scene_datetime','pickup_datetime','dropoff_datetime',
         'shared_request_flag','shared_match_flag','base_passenger_fare','driver_pay','trip_miles']
frames=[];offset=0
for batch in pq.ParquetFile(source).iter_batches(batch_size=100000,columns=columns):
    end=offset+len(batch);wanted=selected[(selected>=offset)&(selected<end)]
    if len(wanted):
        frame=batch.to_pandas().iloc[wanted-offset].copy()
        frame['trip_id']=[identities[int(i)] for i in wanted];frames.append(frame)
    offset=end
extra=pd.concat(frames,ignore_index=True)
assert extra.trip_id.is_unique and set(extra.trip_id)==set(records.trip_id)
extra.to_parquet(O/'source_details.parquet',index=False)
(O/'cache_manifest.json').write_text(json.dumps(dict(source=inputs,counts=counts,records=len(records),extra_rows=len(extra)),indent=2)+'\n')
print('Source cache rows:',len(records),len(extra))
