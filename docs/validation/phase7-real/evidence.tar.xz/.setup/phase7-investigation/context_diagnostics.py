"""Training-only diagnostics and source event coverage; no held-out tuning."""
from pathlib import Path
import json
import numpy as np,pandas as pd
from tools.synthetic_market.build import historical_profiles

I=Path('/workspace/market_inputs');O=Path('/workspace/market_results/investigation')
base=I/'manhattan_10pct_seed0'
meta=json.loads((base/'manifest.json').read_text())
all_rows=pd.read_parquet(I/'investigation_cache/all_day_records.parquet')
details=pd.read_parquet(I/'investigation_cache/source_details.parquet')
details['arrival_s']=(details.on_scene_datetime-details.request_datetime).dt.total_seconds()
details['curb_s']=(details.pickup_datetime-details.on_scene_datetime).dt.total_seconds()
details['valid_arrival']=details.arrival_s.ge(0)&details.curb_s.ge(0)
training=all_rows[all_rows.service_date.isin(meta['training_dates'])].copy()
target=all_rows[all_rows.service_date.eq(meta['target_date'])].copy()
def population(frame,name):
    peak=frame[frame.request_s.ge(25200)&frame.request_s.lt(36000)].merge(details,on='trip_id',validate='one_to_one')
    available=peak[peak.valid_arrival]
    return dict(population=name,peak_requests=len(peak),valid_on_scene=len(available),
        on_scene_coverage=len(available)/len(peak),source_wait_median_all=float(peak.observed_wait_s.median()),
        source_arrival_median_available=float(available.arrival_s.median()),
        source_curb_median_available=float(available.curb_s.median()),
        source_total_wait_median_available=float(available.observed_wait_s.median()),
        shared_request_share=float(peak.shared_request_flag.eq('Y').mean()),
        shared_match_share=float(peak.shared_match_flag.eq('Y').mean()),
        company_counts=peak.hvfhs_license_num.value_counts().to_dict(),
        company_on_scene_counts=available.hvfhs_license_num.value_counts().to_dict())
mapping=pd.read_csv(base/'zones/network/node_zone_info.csv')
old=pd.read_csv(base/'training_cohort.csv')
_,full=historical_profiles(training,3,sorted(mapping.zone_id.unique()),25200,36900,900,.58)
old_supply=pd.read_csv(base/'supply_profile.csv')
full=full.merge(old_supply,on='time',suffixes=('_full_history','_window_only'),validate='one_to_one')
full.to_csv(O/'training_supply_carry_in.csv',index=False)
carry=[]
for t in [18000,21600,25200]:
    busy=training.pickup_s.le(t)&training.dropoff_s.gt(t)
    # Ongoing recorded rides, not distinct vehicles: pooled rides can overlap.
    carry.append(dict(time=t,ongoing_recorded_rides_per_training_day=float(busy.sum()/3)))
centroids=mapping[mapping.is_centroid.eq(1)].set_index('zone_id').node_index.to_dict()
tt=np.load(base/'network/ff/tables/nn_fastest_tt.npy',mmap_mode='r')
fit=old.copy()
fit['ratio']=np.log((fit.dropoff_s-fit.pickup_s)/[tt[centroids[int(a)],centroids[int(b)]] for a,b in zip(fit.PULocationID,fit.DOLocationID)])
fit['bin']=(fit.pickup_s//900*900).astype(int)
residual=fit.ratio-fit.groupby('bin').ratio.transform('mean')
noise=dict(global_log_ratio_sigma=float(fit.ratio.std(ddof=0)),within_bin_residual_sigma=float(residual.std(ddof=0)),
    note='Diagnostic only: all ablations retain baseline factors/sigma; zone imputation and pooling affect identifiability.')
record=dict(training=population(training,'three earlier Tuesdays'),held_out=population(target,'November 26'),
    carry_in=carry,travel_noise=noise,
    limitations=['Completed recorded interzonal trips only, not attempted/cancelled requests',
        '63 supplied zones; intrazonal trips deliberately excluded by the original centroid builder',
        '10% source-row sample; one held-out holiday-week Tuesday and seed 0',
        'Fleet 775 derives from assumed utilization 0.58, not observed online drivers',
        'No observed within-zone coordinates; uniform road-node placement is an imputation',
        'Source shared_match is not equivalent to simulated concurrent occupancy; all requests currently pool-eligible',
        'Per-request patience uses held-out observed wait plus 300s: retrospective replay, not prospective prediction',
        'Original experimental all-request calibration reports include warm-up; independent diagnostics select fixed 07:00–10:00 cohort'])
(O/'source_context.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
