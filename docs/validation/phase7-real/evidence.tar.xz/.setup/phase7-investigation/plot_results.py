"""Export scientific figures; median errors are diagnostics, not confidence bounds."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

O=Path('/workspace/market_results/investigation')
d=pd.read_csv(O/'cohort_diagnostics.csv')
chosen=[('baseline','Original\ncentroid/floor'),('uniform_clock_1s','Road nodes\nexact seconds'),
    ('uniform_clock_warmup_1h','Road nodes\n1-hour warm-up'),('uniform_clock_warmup_2h','Road nodes\n2-hour warm-up'),
    ('uniform_clock_warmup_2h_dynamic_typed','Road nodes\ndynamic supply'),
    ('uniform_clock_1s_train_curb','Road nodes\ntraining curb'),('uniform_ceil_60s_train_curb','Ceiling grid\ntraining curb')]
selected=d[d.arm.eq('repo')&d.pair_status.eq('complete')].set_index('case')
chosen=[(k,label) for k,label in chosen if k in selected.index]
x=selected.loc[[k for k,_ in chosen]]
fig,axes=plt.subplots(1,3,figsize=(15,5.5),layout='constrained')
colors=['#949aab']+['#3274a1']*(len(x)-1)
for ax,col,title,ylabel in [
    (axes[0],'arrival_median_abs_error_s','Vehicle arrival: median error','Absolute error (seconds)'),
    (axes[1],'pickup_total_median_abs_error_s','Departure after boarding: median error','Absolute error (seconds)'),
    (axes[2],'completion_rate','Evaluation-cohort completion','Percent of 3,150 recorded trips')]:
    y=x[col]*(100 if col=='completion_rate' else 1)
    bars=ax.bar(range(len(x)),y,color=colors,width=.72)
    for b,v in zip(bars,y):ax.annotate(f'{v:.1f}',(b.get_x()+b.get_width()/2,b.get_height()),xytext=(0,4),textcoords='offset points',ha='center',fontsize=8)
    ax.set_xticks(range(len(x)),[label for _,label in chosen],rotation=55,ha='right',fontsize=8)
    ax.set_title(title,fontsize=11);ax.set_ylabel(ylabel);ax.set_axisbelow(True);ax.grid(axis='y',alpha=.2)
    ax.set_ylim(0,110 if col=='completion_rate' else max(y)*1.18)
fig.suptitle('Manhattan real-data diagnostics — repositioning arm, seed 0\nOriginal floor-clock baseline admits requests early; candidates are sensitivity tests\nSame 07:00–10:00 cohort; event comparisons conditional on service/arrival availability',fontsize=11)
fig.savefig(O/'calibration_diagnostics.png',dpi=180)
fig.savefig(O/'calibration_diagnostics.svg')
plt.close(fig)
