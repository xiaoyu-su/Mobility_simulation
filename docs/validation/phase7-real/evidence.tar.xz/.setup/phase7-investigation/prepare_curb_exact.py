"""Training-only curb-duration sensitivity; leave the measured target untouched."""
from pathlib import Path
import json,shutil
import pandas as pd
from ablation_lib import OUT,digest

parent=OUT/'uniform_clock_1s';dest=OUT/'uniform_clock_1s_train_curb'
if dest.exists():raise ValueError('Existing curb sensitivity bundle')
source=pd.read_parquet('/workspace/market_inputs/investigation_cache/source_details.parquet')
context=json.loads(Path('/workspace/market_results/investigation/source_context.json').read_text())
curb=float(context['training']['source_curb_median_available'])
assert curb==94
shutil.copytree(parent,dest)
params=json.loads((dest/'parameters.json').read_text());params['op_const_boarding_time']=curb
(dest/'parameters.json').write_text(json.dumps(params,indent=2)+'\n')
meta=json.loads((dest/'manifest.json').read_text())
meta['derivation']=dict(parent_manifest_sha256=digest(parent/'manifest.json'),script_sha256=digest(__file__),
    changes=['constant boarding/curb duration 30 to 94 seconds, median of 6906 valid earlier-Tuesday peak arrival records',
             'training-only sensitivity; provider-specific availability and variable curb time remain limitations'],
    evaluation_start=25200,evaluation_end=36000,target_request_ids_unchanged=True)
meta['output_sha256']={str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file() and p.name!='manifest.json'}
(dest/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
