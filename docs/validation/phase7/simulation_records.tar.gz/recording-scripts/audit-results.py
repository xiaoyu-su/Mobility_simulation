from collections import Counter
from datetime import datetime,timezone
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd

ROOT=Path('/workspace/Mobility_simulation');sys.path.insert(0,str(ROOT))
from tools.paired_eval.__main__ import source_record
from tools.paired_eval.metrics import per_driver_metrics
from tools.synthetic_market.worker import verify_bundle
from src.misc.seeding import file_digest

BASE=Path('/workspace/.setup/phase7');SUITE=BASE/'final-suite';CASES=BASE/'final-cases'
DEST=ROOT/'docs/validation/phase7';DEST.mkdir(parents=True,exist_ok=True)
source=json.loads((SUITE/'source.json').read_text());assert source==source_record()
suite=ET.parse(SUITE/'junit.xml').getroot().find('testsuite')
assert all(int(suite.attrib[k])==0 for k in ['failures','errors','skipped'])
counts=Counter(t.attrib['classname'] for t in suite.findall('testcase'))
baseline=json.loads((ROOT/'tests/regression/baselines/manifest.json').read_text())
assert all(file_digest(ROOT/name)==digest for name,digest in baseline['input_sha256'].items())
old_source=json.loads((ROOT/'docs/validation/phase6/source.json').read_text())
changed=[name for name,digest in old_source['code_files_sha256'].items() if source['code_files_sha256'][name]!=digest]
assert set(changed)=={'environment.yml','src/misc/init_modules.py','tools/paired_eval/metrics.py'},changed
def hashes(folder):
    return {str(p.relative_to(folder)):file_digest(p) for p in sorted(folder.rglob('*')) if p.is_file() and not p.is_symlink()}

full=[];historical=[];market_runs=[]
for location in [SUITE/'simulation-runs',CASES]:
    for marker in sorted(location.rglob('final_state.csv')):
        run=marker.parent
        if not (run/'standard_eval.csv').exists():continue
        users=pd.read_csv(run/'1_user-stats.csv');assert len(users)==100 and users.request_id.is_unique,run
        assert users.pickup_time.notna().equals(users.dropoff_time.notna()),run
        config=json.loads((run/'00_config.json').read_text())
        dynamic=config['scenario_parameters'].get('op_dyn_fs_method')=='TimeBasedFS'
        drivers=per_driver_metrics(run,clip_initial_inactivity=dynamic)
        assert drivers.completed_trips.sum()==users.dropoff_time.notna().sum()
        decisions=run/'driver_acceptance_op_0.csv'
        if decisions.exists():
            rows=pd.read_csv(decisions);served=set(users.loc[users.dropoff_time.notna(),'request_id'])
            assert set(rows.loc[rows.accepted,'request_id']).issubset(served)
            assert set(rows.loc[rows.terminal_decline,'request_id']).isdisjoint(served)
        if (run/'random_streams.json').exists():
            audit=json.loads((run/'random_streams.json').read_text())
            assert sum(x['count'] for x in audit['demand'].values())==100
        contract=run/'market_input_contract.json'
        if contract.exists():
            value=json.loads(contract.read_text())
            assert value['requests']==100 and value['patience_loaded_for_all'] and value['all_booked_requests_completed']
            assert value['booked_requests']==value['completed_requests']==users.dropoff_time.notna().sum()
            assert Path(config['directories']['vehicles']).name=='vehicles'
            assert (Path(config['directories']['vehicles']).parent/'manifest.json').exists()
            market_runs.append(str(run.relative_to(BASE)))
        full.append(dict(directory=str(run.relative_to(BASE)),requests=len(users),completed=int(users.dropoff_time.notna().sum()),
            dynamic_initial_inactivity_bounded=dynamic,driver_accounting_valid=True,output_sha256=hashes(run)))
        if run.is_relative_to(SUITE/'simulation-runs'):
            previous=Path('/workspace/.setup/phase6/final-suite/simulation-runs')/run.relative_to(SUITE/'simulation-runs')
            if (previous/'final_state.csv').exists():
                tables=[]
                for name in ['1_user-stats.csv','standard_eval.csv','2-0_op-stats.csv','final_state.csv',
                    'driver_acceptance_op_0.csv','driver_choice_op_0.csv','future_value_op_0.csv',
                    'ranked_insertion_op_0.csv','forbid_rematch_op_0.csv']:
                    assert (run/name).exists()==(previous/name).exists()
                    if (run/name).exists():
                        pd.testing.assert_frame_equal(pd.read_csv(run/name),pd.read_csv(previous/name),check_exact=True)
                        tables.append(name)
                historical.append(dict(directory=str(run.relative_to(SUITE/'simulation-runs')),exact_tables=tables))

windows=[]
for marker in sorted((SUITE/'simulation-runs').rglob('window_state.json')):
    run=marker.parent;state=json.loads(marker.read_text());assert state['source']==source
    previous=Path('/workspace/.setup/phase6/final-suite/simulation-runs')/run.relative_to(SUITE/'simulation-runs')
    for name in ['cohort_observations.csv','cohort_drivers.csv','window_final_state.csv','2-0_op-stats.csv']:
        pd.testing.assert_frame_equal(pd.read_csv(run/name),pd.read_csv(previous/name),check_exact=True)
    windows.append(dict(directory=str(run.relative_to(BASE)),cohort_count=state['cohort_count'],
        snapshot_sha256=state['snapshot_sha256'],historical_tables_exact=4,output_sha256=hashes(run)))

bundles=[];experiments=[]
for location in [SUITE/'simulation-runs',CASES]:
    for marker in sorted(location.rglob('manifest.json')):
        d=json.loads(marker.read_text());folder=marker.parent
        if 'data_kind' not in d:continue
        assert d['data_kind']=='fixture' and d['source']==source and d['status']=='complete',folder
        if 'training_dates' in d:
            verify_bundle(folder)
            training=pd.read_csv(folder/'training_cohort.csv');observed=pd.read_csv(folder/'observed_cohort.csv')
            assert len(training)==d['training_count']==300 and len(observed)==d['target_count']==100
            assert set(training.service_date)==set(d['training_dates']) and d['target_date'] not in set(training.service_date)
            assert all(day<d['target_date'] for day in d['training_dates'])
            assert file_digest(folder/'vehicles/default_vehtype.csv')==d['vehicle_source_sha256']
            for name,digest in d['network_sha256'].items():assert file_digest(folder/'network'/name)==digest
            bundles.append(dict(directory=str(folder.relative_to(BASE)),network_type=d['network_type'],
                target_count=len(observed),training_count=len(training),travel_noise_sigma=d['travel_noise_sigma'],
                observed_wait_available=d['observed_wait_available'],all_bundle_hashes_verified=True))
        elif 'runs' in d:
            assert len(d['validated_pairs'])==len(d['seeds'])
            for run in d['runs']:
                assert run['status']=='complete' and run['returncode']==0
                output=Path(run['output'])
                if run['arm']=='repo':
                    audit=json.loads((output/'repositioning_op_0.json').read_text())
                    assert audit['solver']=='scipy.optimize.milp/HiGHS'
                    for round in audit['rounds']:
                        assert len(round['flows'])==len(round['assigned_vehicles'])==len(set(round['assigned_vehicles']))
                        for zone,idle in round['idle'].items():
                            outgoing=sum(str(a)==zone for a,b in round['flows']);incoming=sum(str(b)==zone for a,b in round['flows'])
                            assert outgoing<=idle and round['excess'][zone]+incoming-outgoing>=round['targets'][zone]
                else:assert not (output/'repositioning_op_0.json').exists()
            report=json.loads((folder/'calibration_report.json').read_text())
            assert report['calibration_status']=='fixture_validation_only'
            for row in report['runs']:
                assert row['observed_completion_rate'] is None and row['observed_utilization'] is None
            experiments.append(dict(directory=str(folder.relative_to(BASE)),runs=len(d['runs']),pairs=len(d['validated_pairs']),
                reposition_orders=[r.get('repositioning_orders',0) for r in d['runs'] if r['arm']=='repo']))

outcomes=[];isolation=[]
for name in ['insertion','immediate-future-proxy','batch-classes','dynamic-fleet']:
    folder=CASES/name/'experiment';comparison=pd.read_csv(folder/'paired_comparison.csv')
    metrics={}
    for metric in ['completed_requests','rider_wait_mean_s','reposition_distance_m','fleet_modeled_net_earnings_cent']:
        row=comparison.loc[comparison.metric.eq(metric)].iloc[0]
        metrics[metric]={key:float(row[key]) for key in ['baseline_mean','candidate_mean','mean_difference']}
    outcomes.append(dict(case=name,data_kind='fixture',seeds=[0,1,2],metrics=metrics))
    for report in ['paired_comparison.csv','seed_summary.csv','calibration_report.json']:
        shutil.copy2(folder/report,DEST/f'{name}-{report}')
    prior=BASE/'checkpoint-shared-vehicle-cases'/name/'experiment'
    for marker in folder.rglob('final_state.csv'):
        current=marker.parent;old=prior/current.relative_to(folder)
        checked=[]
        for table in ['1_user-stats.csv','2-0_op-stats.csv','standard_eval.csv','final_state.csv','driver_acceptance_op_0.csv']:
            if (current/table).exists():
                pd.testing.assert_frame_equal(pd.read_csv(current/table),pd.read_csv(old/table),check_exact=True);checked.append(table)
        isolation.append(dict(run=str(current.relative_to(CASES)),exact_tables=checked))

assert len(full)==219 and len(market_runs)==56,(len(full),len(market_runs))
assert len(windows)==32 and len(historical)==163
assert len(bundles)==8 and len(experiments)==12,(len(bundles),len(experiments))
validation=dict(recorded_at_utc=datetime.now(timezone.utc).isoformat(),phase='7',branch='phase-7-market-data-pipeline',
    status='implementation_validated_real_data_run_blocked',real_data_status='missing local TLC/Manhattan inputs; public endpoints blocked by cloud proxy CONNECT 403',
    unrun=['Actual November 2019 Manhattan 10% and full-scale runs','Real-data patience/supply/calibration sensitivity','TUM Manhattan city compatibility comparison'],
    source_digest=source['code_digest'],tests=dict(passed=int(suite.attrib['tests']),failed=0,skipped=0,duration_seconds=float(suite.attrib['time']),case_counts=dict(counts)),
    suite_full_simulations=195,additional_fixture_simulations=24,total_full_simulations=len(full),restored_windows=len(windows),
    market_pipeline_full_simulations=len(market_runs),historical_full_runs_exact=len(historical),
    historical_full_tables_exact=sum(len(r['exact_tables']) for r in historical),historical_window_tables_exact=128,
    private_vehicle_isolation_cases_exact=len(isolation),original_input_hashes_unchanged=9,
    changed_preexisting_source_files=changed,remaining_preexisting_source_files_unchanged=len(old_source['code_files_sha256'])-len(changed),
    source_trip_kind='fixture',outcomes=outcomes,experiments=experiments,bundles=bundles,
    scope='Three baseline controllers and three routers; complete labeled fixtures, paired inputs, booked completion, physical/accounting contracts. No real NYC finding is claimed.')
for name,value in [('source.json',source),('validation.json',validation),('run_checks.json',dict(full_simulations=full,restored_windows=windows)),
    ('historical_compatibility.json',historical),('vehicle_isolation_compatibility.json',isolation)]:
    (DEST/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
for name in ['pytest.txt','junit.xml']:shutil.copy2(SUITE/name,DEST/name)
for name in ['data-access.json','initial-unit.txt','checkpoint.txt','checkpoint-junit.xml','corrected.txt','corrected-junit.xml',
    'second-corrected.txt','second-corrected-junit.xml','final-focused.txt','final-focused-junit.xml','guards.txt',
    'install-pyarrow.txt','install-pyarrow-corrected.txt','initial-final-case-recorder.txt','checkpoint-shared-vehicle-cases-console.txt']:
    shutil.copy2(BASE/name,DEST/name)
print(json.dumps({k:v for k,v in validation.items() if k not in ['outcomes','experiments','tests','bundles']},indent=2))
