import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/workspace/Mobility_simulation')
OUT=Path('/workspace/.setup/phase6/final-benchmarks')
OUT.mkdir()
configs=ROOT/'studies/example_study/scenarios'
cases=[('ranked','ir','example_ir_driver_choice','example_ir_ranked_fallback'),
       ('rematch','pool','example_batch_driver_choice_control','example_batch_forbid_rematch'),
       ('menus','pool','example_batch_driver_choice','example_batch_forbid_rematch_menus')]
env=dict(os.environ,PYTHONHASHSEED='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg')
for name,constant,baseline,candidate in cases:
    for workers in [1,2]:
        label=f'{name}-workers-{workers}'
        command=[sys.executable,'-m','tools.windowed_eval','--constant-config',str(configs/f'constant_config_{constant}.csv'),
                 '--baseline-scenarios',str(configs/f'{baseline}.yaml'),'--candidate-scenarios',str(configs/f'{candidate}.yaml'),
                 '--seeds','0','1','2','--window-seconds','2400','--cooldown-seconds','300',
                 '--network-tt-noise-sigma','.3','--workers',str(workers),'--output',str(OUT/label)]
        (OUT/f'{label}-command.json').write_text(json.dumps(dict(command=command,environment={k:env[k] for k in
            ['PYTHONHASHSEED','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','MPLBACKEND']}),indent=2)+'\n')
        print(f'Starting {label}',flush=True)
        with (OUT/f'{label}.txt').open('w') as stream:
            result=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
        if result.returncode:raise RuntimeError(f'{label} failed: see log')
        print(f'Completed {label}',flush=True)
