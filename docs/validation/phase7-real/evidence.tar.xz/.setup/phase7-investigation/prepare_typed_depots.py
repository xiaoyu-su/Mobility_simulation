"""Data-only workaround for depot iterrows float promotion with matrix router."""
import json,shutil
import pandas as pd
from ablation_lib import OUT,digest
from src.misc.config import decode_config_str

parent=OUT/'uniform_clock_warmup_2h_dynamic'
dest=OUT/'uniform_clock_warmup_2h_dynamic_typed'
if dest.exists():raise ValueError('Existing typed-depot bundle')
shutil.copytree(parent,dest)
path=dest/'infra/depots.csv';depots=pd.read_csv(path)
# Explicit zero sockets has the same empty physical socket list as a blank.
depots['charging_units']='0:0';depots.to_csv(path,index=False)
loaded=pd.read_csv(path)
assert all(isinstance(row.node_index,int) for _,row in loaded.iterrows())
assert decode_config_str('0:0')=={0:0}
meta=json.loads((dest/'manifest.json').read_text())
meta['derivation']=dict(parent_manifest_sha256=digest(parent/'manifest.json'),script_sha256=digest(__file__),
    changes=['explicit zero charging sockets prevents pandas iterrows from promoting depot node IDs to floats',
             'same depot IDs, integer road nodes, parking spaces, and zero physical charging sockets',
             'data workaround only; production depot loader still needs integral-ID validation/casting'],
    evaluation_start=25200,evaluation_end=36000,evaluation_request_count=3150,warmup_request_count=751)
meta['output_sha256']={str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file() and p.name!='manifest.json'}
(dest/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Validated integer depot positions and physically identical empty charging socket lists')
