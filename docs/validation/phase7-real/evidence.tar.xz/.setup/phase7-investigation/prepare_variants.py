"""Controlled, immutable data/config ablations; simulator source stays frozen."""
from pathlib import Path
import hashlib,json,shutil
import numpy as np,pandas as pd
from shapely.geometry import shape,Point

ROOT=Path('/workspace/Mobility_simulation')
BASE=Path('/workspace/market_inputs/manhattan_10pct_seed0')
OUT=Path('/workspace/market_inputs/ablation_bundles');OUT.mkdir(exist_ok=True)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
mapping=pd.read_csv(BASE/'zones/network/node_zone_info.csv')
nodes=pd.read_csv(BASE/'network/base/nodes.csv').set_index('node_index')
zdir=Path('/workspace/market_inputs/fleetpy_manhattan/FleetPy_Manhattan/zones/Manhattan_Taxi_Zones')
polys={int(f['properties']['taxi_zone']):shape(f['geometry']) for f in json.loads((zdir/'polygon_definition.geojson').read_text())['features']}
eligible={}
for zone,group in mapping.groupby('zone_id'):
    eligible[int(zone)]=[int(n) for n in sorted(group.node_index) if polys[int(zone)].covers(Point(nodes.loc[n,'pos_x'],nodes.loc[n,'pos_y']))]
    if not eligible[int(zone)]:raise ValueError('Empty polygon road-node pool')
def choose(identity,role,zone):
    pool=eligible[int(zone)]
    h=int.from_bytes(hashlib.sha256(f'manhattan-road-imputation-v1/0/{identity}/{role}'.encode()).digest()[:8],'big')
    return pool[h%len(pool)]
def prepare(name,clock=False,spatial=False,initial=False,single=False,dynamic=False):
    dest=OUT/name
    if dest.exists():raise ValueError('Refusing to overwrite '+name)
    shutil.copytree(BASE,dest)
    observed=pd.read_csv(dest/'observed_cohort.csv')
    demand=pd.read_csv(dest/'demand/requests.csv')
    parameters=json.loads((dest/'parameters.json').read_text());meta=json.loads((dest/'manifest.json').read_text())
    changed=[]
    if spatial:
        observed['start']=[choose(i,'origin',z) for i,z in zip(observed.trip_id,observed.PULocationID)]
        observed['end']=[choose(i,'destination',z) for i,z in zip(observed.trip_id,observed.DOLocationID)]
        demand['start']=observed.start;demand['end']=observed.end
        changed.append('uniform eligible road nodes for target pickup/dropoff, fixed source-row/role hashes')
    if initial:
        old=pd.read_csv(dest/'fleetctrl/initial_vehicle_distribution/market_network/initial.csv')
        zone_by_node=mapping.set_index('node_index').zone_id
        rows=[]
        for row in old.itertuples():
            pool=eligible[int(zone_by_node[row.node_index])]
            rows.extend(dict(node_index=n,probability=row.probability/len(pool)) for n in pool)
        pd.DataFrame(rows).to_csv(dest/'fleetctrl/initial_vehicle_distribution/market_network/initial.csv',index=False)
        changed.append('uniform initial vehicle positions within the same training zone probabilities/order')
    if single:
        path=dest/'vehicles/default_vehtype.csv';text=path.read_text()
        if 'maximum_passengers,4' not in text:raise ValueError('Unexpected source capacity')
        path.write_text(text.replace('maximum_passengers,4','maximum_passengers,1'))
        changed.append('vehicle capacity 1 instead of 4; capacity sensitivity, not observed fleet census')
    if clock:
        parameters.update(time_step=1,op_reoptimisation_timestep=1)
        demand['rq_time']=np.floor(observed.request_s).astype(int)
        demand['latest_start_time']=observed.request_s+np.ceil(observed.observed_wait_s)+300
        changed.append('one-second admission grid and raw-request-based patience deadlines')
    if dynamic:
        parameters.update(op_dyn_fs_method='TimeBasedFS',op_act_fs_file='active.csv',infra_structure_name='market_infra',op_depot_file='depots.csv')
        changed.append('enable existing time-based supply profile; profile left-truncation investigated separately')
    observed.to_csv(dest/'observed_cohort.csv',index=False);demand.to_csv(dest/'demand/requests.csv',index=False)
    (dest/'parameters.json').write_text(json.dumps(parameters,indent=2)+'\n')
    meta['derivation']=dict(parent_manifest_sha256=digest(BASE/'manifest.json'),script_sha256=digest(__file__),
        changes=changed,road_factors_and_noise='unchanged from baseline training fit',target_request_ids_unchanged=True,
        evaluation_start=25200,evaluation_end=36000)
    meta['assumptions']['spatial_mapping']=changed if spatial else meta['assumptions']['spatial_mapping']
    meta['output_sha256']={str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file() and p.name!='manifest.json'}
    (dest/'manifest.json').write_text(json.dumps(meta,indent=2,allow_nan=False)+'\n')
    print(name,changed,flush=True)
for name,kwargs in [
    ('clock_1s',dict(clock=True)),
    ('uniform_requests',dict(spatial=True)),
    ('uniform_requests_initial',dict(spatial=True,initial=True)),
    ('uniform_single',dict(spatial=True,initial=True,single=True)),
    ('uniform_single_clock_1s',dict(spatial=True,initial=True,single=True,clock=True)),
]:prepare(name,**kwargs)
