from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import json,os,subprocess,sys,time

ROOT=Path('/workspace/Mobility_simulation');OUT=Path('/workspace/market_results/ablations');OUT.mkdir(exist_ok=True)
CONFIG=Path('/workspace/market_inputs/ablation_bundles')
cases=['clock_1s','uniform_requests','uniform_requests_initial','uniform_single','uniform_single_clock_1s']
env=dict(os.environ,PYTHONHASHSEED='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg')
def run(name):
    cmd=[sys.executable,'-u','-m','tools.synthetic_market','run','--bundle',str(CONFIG/name),'--seeds','0','--timeout','3600','--output',str(OUT/name)]
    record=dict(case=name,command=cmd,started=time.monotonic())
    (OUT/f'{name}-command.json').write_text(json.dumps(record,indent=2)+'\n')
    print('START',name,flush=True)
    with (OUT/f'{name}.txt').open('w') as stream:
        result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=7500)
    record.update(returncode=result.returncode,wall_seconds=time.monotonic()-record['started'])
    print('END',name,result.returncode,round(record['wall_seconds'],1),flush=True)
    return record
records=[]
with ThreadPoolExecutor(max_workers=2) as pool:
    for future in as_completed([pool.submit(run,name) for name in cases]):records.append(future.result())
(OUT/'execution.json').write_text(json.dumps(records,indent=2)+'\n')
if any(r['returncode'] for r in records):raise SystemExit('Ablation failures; inspect preserved logs')
