"""Pack final and checkpoint raw evidence; read back every regular file hash."""
from pathlib import Path
import hashlib
import json
import tarfile

BASE=Path('/workspace/.setup/phase6')
DEST=Path('/workspace/Mobility_simulation/docs/validation/phase6')
DEST.mkdir(parents=True,exist_ok=True)
groups={
    'suite_records.tar.gz':[(BASE/'final-suite','suite')],
    'benchmark_records.tar.gz':[(BASE/'final-benchmarks','benchmarks')],
    'checkpoint_records.tar.gz':[(BASE/name,'checkpoints/'+name) for name in
        ['checkpoint-interrupted-suite','checkpoint-logging-benchmarks','probe-diagnosis',
         'probe-insertion','probe-insertion-v2','probe-insertion-v3','smoke-ranked','smoke-rematch']]
}
index={}
for name,roots in groups.items():
    members={};originals={};archive=DEST/name
    with tarfile.open(archive,'w:gz') as tar:
        for folder,prefix in roots:
            for path in sorted(folder.rglob('*')):
                if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts:continue
                target=prefix+'/'+str(path.relative_to(folder))
                members[target]=hashlib.sha256(path.read_bytes()).hexdigest();originals[target]=path
                tar.add(path,arcname=target,recursive=False)
        if name=='benchmark_records.tar.gz':
            for script in ['run-benchmarks.py','audit-results.py','archive-evidence.py']:
                path=BASE/script;target='recording-scripts/'+script
                members[target]=hashlib.sha256(path.read_bytes()).hexdigest();originals[target]=path
                tar.add(path,arcname=target,recursive=False)
    checked=set()
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            assert member.isfile(),member.name
            digest=hashlib.sha256(tar.extractfile(member).read()).hexdigest()
            assert digest==members[member.name]
            assert digest==hashlib.sha256(originals[member.name].read_bytes()).hexdigest()
            checked.add(member.name)
    assert checked==set(members)
    index[name]=dict(regular_files=len(members),size_bytes=archive.stat().st_size,
        sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),file_sha256=members)
    print(name,len(members),archive.stat().st_size,flush=True)
(DEST/'archive_index.json').write_text(json.dumps(index,indent=2)+'\n')
validation=json.loads((DEST/'validation.json').read_text())
validation['archives']={k:{key:value for key,value in v.items() if key!='file_sha256'} for k,v in index.items()}
validation['artifact_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(DEST.iterdir())
    if p.is_file() and p.name not in ['validation.json','README.md']}
(DEST/'validation.json').write_text(json.dumps(validation,indent=2,allow_nan=False)+'\n')
