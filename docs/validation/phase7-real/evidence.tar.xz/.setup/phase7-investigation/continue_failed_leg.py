"""Forensic movement continuation from observed cutoff state; not a policy run."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json
from src.routing.road.NetworkTTMatrix import NetworkTTMatrix
from src.simulation.Vehicles import SimulationVehicle

O=Path('/workspace/market_results/investigation')
trace=O/'clock_debug_trace.jsonl'
events=[json.loads(x) for x in trace.read_text().splitlines()]
state=next(x for x in events if x['event']=='unfinished_after_drain' and x['vehicle']==356)
multiplier=next(x['multiplier'] for x in events if x['event']=='movement_before')
router=NetworkTTMatrix('/workspace/market_inputs/manhattan_10pct_seed0/network',network_dynamics_file_name='calibrated_factors.csv')
for t in router.sorted_tt_factor_times:router.update_network(t)
router.update_network(50400)
v=SimpleNamespace(_execution_rng=object(),cl_tt_multiplier=multiplier,routing_engine=router,
    cl_remaining_route=state['route'].copy(),pos=tuple(state['position']),assigned_route=[SimpleNamespace(destination_pos=(537,None,None))],
    op_id=0,vid=356,replay_flag=True,cl_driven_distance=0,soc=1,compute_soc_consumption=lambda distance:0,
    cl_driven_route=[],cl_driven_route_times=[],cl_toll_costs=0)
arrival=None
for t in range(50400,60000):
    result=SimulationVehicle._move(v,t,1,t)
    router.update_network(t+1)
    if result!=-1:
        arrival=result;break
assert arrival is not None and v.pos==(537,None,None)
record=dict(kind='isolated forensic continuation, not a canonical successful simulation or calibration result',
    trace_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),request_id=2665,vehicle_id=356,
    cutoff_seconds=50400,execution_multiplier=multiplier,cutoff_position=state['position'],
    arrival_seconds=arrival,arrival_after_cutoff_s=arrival-50400,boarding_end_seconds=arrival+30,
    vehicle_reached_original_destination=True,production_code_changed=False,
    conclusion='Finite four-hour post-run drain cutoff truncates this long stochastic leg; the vehicle was still progressing.')
(O/'failed_leg_continuation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
