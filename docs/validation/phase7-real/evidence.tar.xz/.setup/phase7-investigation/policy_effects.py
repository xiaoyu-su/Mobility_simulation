"""Within-bundle policy effects, including common-served cohorts and costs."""
from pathlib import Path
import json,pandas as pd

I=Path('/workspace/market_inputs');R=Path('/workspace/market_results');O=R/'investigation'
cases=[('baseline',I/'manhattan_10pct_seed0',R/'manhattan_10pct_seed0')]
cases += [(p.name,I/'ablation_bundles'/p.name,p) for p in sorted((R/'ablations').iterdir()) if p.is_dir()]
rows=[]
for name,bundle,folder in cases:
    manifest=json.loads((folder/'manifest.json').read_text())
    if manifest['status']!='complete':continue
    observed=pd.read_csv(bundle/'observed_cohort.csv')
    observed=observed[observed.request_s.ge(25200)&observed.request_s.lt(36000)].set_index('request_id')
    assert len(observed)==3150
    arms={a:pd.read_csv(folder/'runs/seed_0'/a/'1_user-stats.csv').set_index('request_id').loc[observed.index] for a in ['no_repo','repo']}
    served={a:u.pickup_time.notna() for a,u in arms.items()}
    waits={a:u.pickup_time-observed.request_s for a,u in arms.items()}
    common=served['no_repo']&served['repo']
    changes=waits['repo'][common]-waits['no_repo'][common]
    drivers=pd.read_csv(folder/'per_driver.csv')
    net={a:float(drivers.loc[drivers.arm.eq(a),'modeled_net_earnings_cent'].sum()) for a in arms}
    legs=pd.read_csv(folder/'runs/seed_0/repo/2-0_op-stats.csv')
    params=json.loads((bundle/'parameters.json').read_text())
    rows.append(dict(case=name,seed=0,evaluation_requests=3150,
        completed_no_repo=int(served['no_repo'].sum()),completed_repo=int(served['repo'].sum()),
        additional_completed=int(served['repo'].sum()-served['no_repo'].sum()),
        completion_difference_percentage_points=float((served['repo'].mean()-served['no_repo'].mean())*100),
        common_served_requests=int(common.sum()),
        common_served_wait_median_no_repo_s=float(waits['no_repo'][common].median()),
        common_served_wait_median_repo_s=float(waits['repo'][common].median()),
        common_served_median_individual_wait_change_s=float((waits['repo'][common]-waits['no_repo'][common]).median()),
        common_served_mean_individual_wait_change_s=float(changes.mean()),
        common_served_improved_count=int(changes.lt(-1e-7).sum()),
        common_served_worsened_count=int(changes.gt(1e-7).sum()),
        common_served_unchanged_count=int(changes.abs().le(1e-7).sum()),
        early_pickups_no_repo=int(waits['no_repo'].lt(-1e-7).sum()),early_pickups_repo=int(waits['repo'].lt(-1e-7).sum()),
        whole_run_reposition_distance_km=float(legs.loc[legs.status.eq('reposition'),'driven_distance'].sum()/1000),
        whole_run_modeled_net_no_repo_cent=net['no_repo'],whole_run_modeled_net_repo_cent=net['repo'],
        whole_run_modeled_net_difference_cent=net['repo']-net['no_repo'],
        whole_run_start_s=params['start_time'],whole_run_end_s=params['end_time'],
        cost_scope='entire simulated horizon plus recorded fulfillment tail; illustrative model, not observed NYC wages'))
pd.DataFrame(rows).to_csv(O/'policy_effects.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
