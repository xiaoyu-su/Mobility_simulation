"""Independent real-cohort diagnostics; never overwrite simulation reports."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from scipy.stats import wasserstein_distance,ks_2samp

INPUT=Path('/workspace/market_inputs')
RESULT=Path('/workspace/market_results')
OUT=RESULT/'investigation';OUT.mkdir(exist_ok=True)
details=pd.read_parquet(INPUT/'investigation_cache/source_details.parquet')
details['observed_arrival_wait_s']=(details.on_scene_datetime-details.request_datetime).dt.total_seconds()
details['observed_curb_s']=(details.pickup_datetime-details.on_scene_datetime).dt.total_seconds()
details['valid_arrival']=details.observed_arrival_wait_s.ge(0)&details.observed_curb_s.ge(0)
base=pd.read_csv(INPUT/'manhattan_10pct_seed0/observed_cohort.csv')
cases=[('baseline',INPUT/'manhattan_10pct_seed0',RESULT/'manhattan_10pct_seed0')]
cases += [(p.name,INPUT/'ablation_bundles'/p.name,p) for p in sorted((RESULT/'ablations').iterdir()) if p.is_dir()]
rows=[];distribution=[];integrity=[];pending=[];failures=[];timebins=[]
def quantile(x,p):return float(x.quantile(p)) if len(x.dropna()) else None
def ids(value):
    if pd.isna(value):return []
    return [int(float(v)) for v in str(value).split(';')]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for case,bundle,folder in cases:
    path=folder/'manifest.json'
    if not path.exists():
        pending.append(case);continue
    manifest=json.loads(path.read_text())
    if manifest['status']=='running':pending.append(case)
    observed=pd.read_csv(bundle/'observed_cohort.csv')
    cohort=observed[observed.request_s.ge(25200)&observed.request_s.lt(36000)].copy()
    assert len(cohort)==3150 and set(cohort.trip_id)==set(base.trip_id)
    assert cohort.request_id.is_unique and set(cohort.request_id)==set(base.request_id)
    cohort=cohort.merge(details,on='trip_id',validate='one_to_one')
    for arm in ['no_repo','repo']:
        run=folder/'runs/seed_0'/arm
        entry=next((r for r in manifest['runs'] if r['arm']==arm),None)
        if entry is None or entry['status']=='running':continue
        if entry['status']=='failed':
            u=pd.read_csv(run/'1_user-stats.csv') if (run/'1_user-stats.csv').exists() else pd.DataFrame()
            failures.append(dict(case=case,arm=arm,error=manifest.get('error'),
                unfinished_picked_up_request_ids=u.loc[u.pickup_time.notna()&u.dropoff_time.isna(),'request_id'].tolist() if len(u) else None))
            continue
        users=pd.read_csv(run/'1_user-stats.csv')
        legs=pd.read_csv(run/'2-0_op-stats.csv')
        contract=json.loads((run/'market_input_contract.json').read_text())
        assert users.request_id.is_unique and set(users.request_id)==set(observed.request_id)
        assert contract['all_booked_requests_completed'] and contract['patience_loaded_for_all']
        assert users.loc[users.pickup_time.notna(),'dropoff_time'].notna().all()
        assert users.loc[users.operator_id.isna(),'pickup_time'].isna().all()
        assert (legs.end_time>=legs.start_time-1e-7).all()
        capacity=int(next(line.split(',')[1] for line in (bundle/'vehicles/default_vehtype.csv').read_text().splitlines() if line.startswith('maximum_passengers,')))
        assert legs.loc[legs.status.eq('route'),'occupancy'].le(capacity).all()
        repo_checks={}
        if arm=='repo':
            audit=json.loads((run/'repositioning_op_0.json').read_text())
            for round_ in audit['rounds']:
                assert len(set(round_['assigned_vehicles']))==len(round_['assigned_vehicles'])
                assert len(round_['flows'])==len(round_['assigned_vehicles'])
            orders=sum(len(r['assigned_vehicles']) for r in audit['rounds'])
            physical=int(legs.status.eq('reposition').sum())
            assert orders>0 and physical>0
            repo_checks=dict(repositioning_rounds=len(audit['rounds']),assigned_repositioning_orders=orders,
                physical_repositioning_legs=physical,unique_repositioned_vehicles_per_round=True)
        for _,group in legs.groupby('vehicle_id',sort=False):
            ordered=group.sort_values(['start_time','end_time'])
            assert np.all(ordered.start_time.to_numpy()[1:]>=ordered.end_time.to_numpy()[:-1]-1e-7)
        pooled=set()
        for leg in legs[legs.status.eq('route')&legs.occupancy.ge(2)].itertuples():pooled.update(ids(leg.rq_on_board))
        departures={};boarding_start={}
        for leg in legs[legs.status.eq('boarding')].itertuples():
            for rid in ids(leg.rq_boarding):
                assert rid not in departures
                departures[rid]=leg.end_time;boarding_start[rid]=leg.start_time
        joined=cohort.merge(users,on='request_id',suffixes=('_source','_sim'),validate='one_to_one')
        served=joined.pickup_time.notna();complete=joined.dropoff_time.notna()
        raw=joined.loc[served,'pickup_time']-joined.loc[served,'request_s']
        grid=joined.loc[served,'pickup_time']-joined.loc[served,'rq_time']
        observed_wait=joined.loc[served,'observed_wait_s']
        ride=joined.loc[complete,'dropoff_time']-joined.loc[complete,'pickup_time']
        source_ride=joined.loc[complete,'dropoff_s']-joined.loc[complete,'pickup_s']
        joined['model_departure']=joined.request_id.map(departures)
        joined['model_boarding_start']=joined.request_id.map(boarding_start)
        assert joined.loc[served,'model_departure'].notna().all()
        assert np.allclose(joined.loc[served,'model_boarding_start'],joined.loc[served,'pickup_time'])
        arrival=served&joined.valid_arrival
        departure_wait=joined.loc[served,'model_departure']-joined.loc[served,'request_s']
        source_matched_arrival=joined.loc[arrival,'observed_arrival_wait_s']
        model_matched_arrival=joined.loc[arrival,'pickup_time']-joined.loc[arrival,'request_s']
        both=joined.loc[served].request_id.isin(pooled)
        record=dict(case=case,seed=0,arm=arm,pair_status=manifest['status'],requests=len(joined),completed=int(complete.sum()),
            completion_rate=float(complete.mean()),raw_wait_median_s=quantile(raw,.5),grid_wait_median_s=quantile(grid,.5),
            raw_wait_p10_s=quantile(raw,.1),raw_wait_p90_s=quantile(raw,.9),
            source_pickup_wait_median_all_s=quantile(joined.observed_wait_s,.5),
            source_pickup_wait_median_served_s=quantile(observed_wait,.5),
            raw_wait_negative_count=int(raw.lt(-1e-7).sum()),grid_zero_wait_count=int(grid.abs().lt(1e-7).sum()),
            raw_wait_min_s=float(raw.min()),mean_admission_offset_s=float((joined.rq_time-joined.request_s).mean()),
            boarding_departure_wait_median_s=quantile(departure_wait,.5),
            pickup_total_median_abs_error_s=abs(quantile(departure_wait,.5)-quantile(observed_wait,.5)),
            pickup_total_wasserstein_s=float(wasserstein_distance(departure_wait,observed_wait)),
            pickup_total_ks=float(ks_2samp(departure_wait,observed_wait).statistic),
            arrival_comparison_count=int(arrival.sum()),source_arrival_available_count=int(joined.valid_arrival.sum()),
            model_arrival_median_matched_s=quantile(model_matched_arrival,.5),
            source_arrival_median_matched_s=quantile(source_matched_arrival,.5),
            arrival_median_abs_error_s=abs(quantile(model_matched_arrival,.5)-quantile(source_matched_arrival,.5)),
            arrival_wasserstein_s=float(wasserstein_distance(model_matched_arrival,source_matched_arrival)),
            ride_median_s=quantile(ride,.5),source_ride_median_served_s=quantile(source_ride,.5),
            ride_median_abs_error_s=abs(quantile(ride,.5)-quantile(source_ride,.5)),
            post_boarding_ride_median_s=quantile(joined.loc[complete,'dropoff_time']-joined.loc[complete,'model_departure'],.5),
            model_pooled_share_served=float(both.mean()),
            source_pooled_share_served=float(joined.loc[served,'shared_match_flag'].eq('Y').mean()),
            warmup_requests=len(observed)-len(cohort),total_simulation_requests=len(users))
        rows.append(record)
        for begin in range(25200,36000,1800):
            part=joined[joined.request_s.ge(begin)&joined.request_s.lt(begin+1800)]
            ok=part.pickup_time.notna()
            timebins.append(dict(case=case,arm=arm,start_seconds=begin,requests=len(part),completed=int(part.dropoff_time.notna().sum()),
                model_arrival_wait_median_s=quantile(part.loc[ok,'pickup_time']-part.loc[ok,'request_s'],.5),
                model_departure_wait_median_s=quantile(part.loc[ok,'model_departure']-part.loc[ok,'request_s'],.5),
                source_pickup_wait_median_served_s=quantile(part.loc[ok,'observed_wait_s'],.5)))
        for p in [.1,.25,.5,.75,.9,.95]:
            distribution.append(dict(case=case,arm=arm,quantile=p,model_arrival_raw_s=quantile(raw,p),
                model_boarding_departure_s=quantile(departure_wait,p),source_pickup_s=quantile(observed_wait,p),
                model_arrival_matched_s=quantile(model_matched_arrival,p),source_arrival_matched_s=quantile(source_matched_arrival,p)))
        integrity.append(dict(case=case,arm=arm,source_digest=manifest['source']['code_digest'],
            source_git_head=manifest['source']['git_head'],manifest_sha256=sha(path),
            unique_complete_demand=True,bookings_complete=True,chronological_activity=True,
            route_capacity_respected=True,capacity=capacity,
            **repo_checks,
            boarding_event_matches_pickup_time=True,identical_evaluation_trip_ids=True,
            source_reference_no_early_pickups=not raw.lt(-1e-7).any(),
            raw_output_sha256={p.name:sha(p) for p in run.iterdir() if p.is_file()}))
pd.DataFrame(rows).to_csv(OUT/'cohort_diagnostics.csv',index=False)
pd.DataFrame(distribution).to_csv(OUT/'wait_quantiles.csv',index=False)
pd.DataFrame(timebins).to_csv(OUT/'timebin_diagnostics.csv',index=False)
(OUT/'integrity.json').write_text(json.dumps(dict(completed_runs=len(rows),pending_cases=pending,failures=failures,checks=integrity),indent=2)+'\n')
print(pd.DataFrame(rows)[['case','arm','completed','raw_wait_median_s','raw_wait_negative_count','boarding_departure_wait_median_s','arrival_median_abs_error_s','model_pooled_share_served']].to_string(index=False))
print('PENDING',pending)
